//var vcapServices = require('vcap_services');
var express = require('express');  
var bodyParser = require('body-parser'); 
var ejs = require('ejs');
var JSAlert = require("js-alert");
//const Dialogs = require('dialogs');
//const dialogs = Dialogs();
var popup = require('window-popup').windowPopup;
var MongoClient = require('mongodb').MongoClient;
var app = express(); 
//var popup = require('popups'); 
var urlencodedParser = bodyParser.urlencoded({ extended: false })
// Connect to the db

MongoClient.connect("mongodb://127.0.0.1/TrainReservation", function(err, db) {
 if(!err) {
    console.log("We are connected");

app.use(express.static('public')); //making public directory as static directory  
app.use(bodyParser.json());
app.get('/home', function (req, res) {  
   console.log("Got a GET request for the homepage");  
   res.send('<h1>Welcome to RIT</h1>');   
})

app.get('/about', function (req, res) {  
   console.log("Got a GET request for /about");  
   res.send('Dept. of Computer Science & Engineering');
})  
/*JS client side files has to be placed under a folder by name 'public' */


//__--------Print All train Details----------------------
app.get('/trainDetails', function (req, res) {  
  console.log("Got a GET request for /about");  
  db.collection('Train').find().sort({TrainId:1}).toArray(
    function(err , i){
       if (err) return console.log(err)
       res.render('ViewTrain.ejs',{Train: i})  
    })
//---------------------// sort({empid:-1}) for descending order -----------//
}) 
 
//-----------------print all tickets details----------------
app.get('/AllTicket', function (req, res) {  
  console.log("Got a GET request for /about");  
  db.collection('PassTicket').find().toArray(
    function(err , i){
       if (err) return console.log(err)
       res.render('ViewTicket.ejs',{PassTicket: i})  
    })
//---------------------// sort({empid:-1}) for descending order -----------//
}) 



app.get('/printTicket', function (req, res) {  
  console.log("Got a GET request for /about");  
  db.collection('PassTicket').find().toArray(
    function(err , i){
       if (err) return console.log(err)
       res.render('PrintBookedTicket.ejs',{PassTicket: i})  
    })
//---------------------// sort({empid:-1}) for descending order -----------//
}) 
 

app.get('/index.html', function (req, res) {  
   res.sendFile( __dirname + "/" + "index.html" );    
})  


//--------------routes with check for seats-----------------
app.get('/insert.html', function (req, res) {
    res.sendFile( __dirname + "/" + "insert.html" );
})
/* to access the posted data from client using request body (POST) or request params(GET) */
//-----------------------POST METHOD for booking-------------------------------------------------
app.post('/process_post', function (req, res) {
    /* Handling the AngularJS post request*/
    console.log(req.body);
	res.setHeader('Content-Type', 'text/html');
    req.body.serverMessage = "NodeJS replying to angular"
        /*adding a new field to send it to the angular Client */
		console.log("Sent data are (POST): FromCity :"+req.body.from+" DestinationCity"+req.body.to+"Train Name"+req.body.trainName);
    // Submit to the DB
    var trnName=req.body.trainName;
  	var from = req.body.from;
    var to = req.body.to;
    var Sdate=JSON.stringify(req.body.selectDate);
    var T_seat=req.body.seatType;
    var time1=JSON.stringify(req.body.Stime);
	//To avoid duplicate entries in MongoDB
//	db.collection('TicketBooking').createIndex({"bookingId":1},{unique:true});
	/*response has to be in the form of a JSON*/
	db.collection('TicketBooking').insertOne({TrainName:trnName,fromCity:from,DestiniCity:to,date:Sdate,type_seat:T_seat,Time:time1}, (err, result) => {                       
                    if(err) 
					{ 
						console.log(err.message); 
						res.send("Duplicate Booking ID")
					} 
					else
					{
            console.log('Ticket booked Inserted');
          /*Sending the respone back to the angular Client */
          res.redirect("insert.html")
          app.get("/",function(req,res){doc.render(insert.html)})
					res.end("Ticket Inserted-->"+JSON.stringify(req.body));
					}
          })      
	
    });
//--------------------------GET METHOD for booking-------------------------------
app.get('/process_get', function (req, res) { 
// Submit to the DB
    var newTicket = req.query;
    var trnName=req.query['trainName'];
	 var fromCiti = req.query['from'];
    var destiniCiti = req.query['to'];
    var date=req.query['selectDate'];
    var time=req.query['time'];
    var T_seat=req.query['seatType'];
  
	db.collection('TicketBooking').createIndex({"ticketId":1},{unique:false});
	db.collection('TicketBooking').insertOne({TrainName:trnName,fromCity:from,Destini:to,date:Sdate,type_seat:T_seat,time:time}, (err, result) => {                       
                    if(err) 
					{ 
						console.log(err.message); 
						res.send("Duplicate Employee ID")
					} 
					else
					{
                    console.log("Ticket booked Inserted");
					/*Sending the respone back to the angular Client */
					res.end("ticket  Inserted-->"+JSON.stringify(newTicket));
					}
                })      
}) 

//-----------------------POST METHOD for Passanger insert passanger details-------------------------------------------------
app.post('/process_post_passanger', function (req, res) {
  var city;
  var tick;
  /* Handling the AngularJS post request*/
  console.log(req.body);
res.setHeader('Content-Type', 'text/html');
  req.body.serverMessage = "NodeJS replying to angular"
      /*adding a new field to send it to the angular Client */
  console.log("Sent data are (POST): Passanger Name :"+req.body.P_Name+" phone_number"+req.body.P_num);
  // Submit to the DB
  var name = req.body.P_Name;
  var phone = req.body.P_num;
  var email=req.body.email;
  var age=req.body.age;
  var address=req.body.address;
//To avoid duplicate entries in MongoDB
//db.collection('PassengerDetails').createIndex({"passanger":1},{unique:false});
/*response has to be in the form of a JSON*/
db.collection('PassengerDetails').insertOne({Name:name,PhoneNumber:phone,EmailId:email,age:age,Address:address}, (err, result) => {                       
                  if(err) 
        { 
          console.log(err.message); 
          res.send("Duplicate Passanger ID")
        } 
        else
       {
          console.log('passanger data Inserted');
        /*Sending the respone back to the angular Client */
        
        var RTicketId=JSON.stringify(Math.floor((Math.random()*500)+1));

      db.collection('TicketBooking').find({}).toArray(function(err,docs){
        var price=100;
       var seat=docs[0].type_seat;  
        if(seat=="FisrtClass")
          price=200;
        else if(seat=="SecondClass")
         price=150;
         else if(seat=="General")
         price=250;
         else if(seat=="AC_Sleeper")
         price=500;
         else
         price=100;

         var len=docs.length;
        
       db.collection('PassTicket').insertOne({TicketId:RTicketId,Name:name,PhoneNumber:phone,EmailId:email,age:age,Address:address,TrainName:docs[0].TrainName,fromCity:docs[0].fromCity,Destini:docs[0].DestiniCity,date:docs[0].date,type_seat:docs[0].type_seat,Time:docs[0].time,TicketPrice:price},(err, result) => 
       {
         if(err)
         console.log(err.message);
         else
         {
         console.log("data inserted into passticket");
        // dialogs.alert(RTicketId,ok=>{console.log("booked")});
        //res.end("ticket Inserted-->"+JSON.stringify(req.body));
         }
       })

      })
       res.end("passanger details Inserted-->"+JSON.stringify(req.body))
      // res.sendFile("./views/ConfirmTicket.ejs");
        }

      })

  });

//--------------------------GET METHOD for Passanger-------------------------------
app.get('/process_get_passanger', function (req, res) { 
  // Submit to the DB
      var newpassanger= req.query;
     var name = req.query['P_Name'];
      var phone = req.query['P_num'];
      var email=req.query['email'];
      var age=req.query['age'];
      var address=req.query['address'];
    
    db.collection('PassengerDetails').createIndex({"PassangerId":1},{unique:false});
    db.collection('PassengerDetails').insertOne({Name:name,PhoneNumber:phone,EmailId:email,age:age,Address:address}, (err, result) => {                       
                      if(err) 
            { 
              console.log(err.message); 
              res.send("Duplicate passanger ID")
            } 
            else
            {
                      console.log("passanger Inserted");
            /*Sending the respone back to the angular Client */
            db.collection('TicketBooking').find().toArray(function(err , docs){
              if (err) return console.log(err)
               res.render('ViewTicket.ejs',{TicketBooking: docs})  
                })
           // res.end("passanger  Inserted-->"+JSON.stringify(newpassanger));
            }
                  })
  }) 

//--------------UPDATE------------------------------------------
app.get('/updateTicketDetails.html', function (req, res) {
    res.sendFile( __dirname + "/" + "updateTicketDetails.html" );
})


app.get("/updateTicketDetails", function(req, res) {  
  var ticketID1=req.query.ticketId;
	var tName=req.query.trainName;
	var fromAdd=req.query.from;
	var toAdd=req.query.to;
	var SDate=req.query.selectDate;
	var Stype=req.query.seatType;
	var Stime=req.query.time;
	var PName=req.query.P_Name;
  var PNum=req.query.P_num;
  var email=req.query.email;
  var Age=req.query.age;
  var Address=req.query.address;
    db.collection('PassTicket', function (err, data) {
        data.update({"TicketId":ticketID1},{$set:{"TrainName":tName,"fromCity":fromAdd,"DestiniCity":toAdd,"date":SDate,"type_seat":Stype,"time":Stime,"Name":PName,"PhoneNumber":PNum,"EmailId":email,"age":Age,"Address":Address}},{multi:true},
            function(err, obj){
				if (err) {
					console.log("Failed to update data.");
			} else {
				if (obj.result.n==1)
				{
				res.send("Ticket number"+"<br/>"+ticketID1+":"+"<b> Updated</b>");
				console.log("ticket Updated")
				}
				else
					res.send("Ticket Not Found")
			}
        });
    });
})	
  


//--------------SEARCH------------------------------------------
app.get('/printMyTicket.html', function (req, res) {  
   res.sendFile( __dirname + "/" + "printMyTicket.html" );    
})

app.get("/printMyTicket", function(req, res) {
	//var empidnum=parseInt(req.query.empid)  // if empid is an integer
	var BticketId=req.query.ticketId;
    db.collection('PassTicket').find({TicketId:BticketId}).toArray(function(err, docs) {
    if (err) {
      console.log(err.message+ "Failed to get data.");
    } else {
      console.log(docs.Name)
        // res.status(200).json(docs);
         res.render('printSearchTicket.ejs',{PassTicket: docs})
    }
  });
  });
  // --------------To find "Single Document"-------------------
	/*var empidnum=parseInt(req.query.empid)
    db.collection('employee').find({'empid':empidnum}).nextObject(function(err, doc) {
    if (err) {
      console.log(err.message+ "Failed to get data");
    } else {
      res.status(200).json(doc);
    }
  })
}); */

//--------------DELETE------------------------------------------
app.get('/DeleteMyTicket.html', function (req, res) {  
   res.sendFile( __dirname + "/" + "DeleteMyTicket.html" );    
})



app.get("/DeleteMyTicket", function(req, res) {
	//var clgcodenum=parseInt(req.query.clgcode)  // if empid is an integer
	var DticketId=req.query.ticketId;
	db.collection('PassTicket', function (err, data) {
        data.remove({"TicketId":DticketId},function(err, obj){
				if (err) {
					console.log("Failed to remove data.");
			} else {
				if (obj.result.n>=1)
				{
				res.send("Your Ticket Number"+"<br/>"+DticketId+": "+"is Cancelled");
				console.log("Ticket Deleted")
				}
				else
					res.send("ticket Not Booked")
			}
        });
    });
    
  });


app.get('/ViewTicket.html', function (req, res) {  
  res.sendFile( __dirname + "/" + "ViewTicket.html" );    
})

//-------------------DISPLAY-----------------------
app.get('/ViewTicket', function (req, res) { 
//------------- USING EMBEDDED JS -----------
 db.collection('TicketBooking').find().toArray(function(err , docs){
        if (err) return console.log(err)
        res.render('ConfirmTicket.ejs',{TicketBooking: docs[0]})  
     })

}) 




 
var server = app.listen(5000, function () {  
var host = server.address().address  
  var port = server.address().port  
console.log("MEAN Stack app listening at http://%s:%s", host, port)  
})  
}
else
{ 
   
   db.close();  }
});
